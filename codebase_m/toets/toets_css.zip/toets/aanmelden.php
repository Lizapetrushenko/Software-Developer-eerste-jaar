<!DOCTYPE html>
<html lang="en">
<head>
    
    <title>Document</title>
    <style>
    input{
            display:flex;
            flex-direction: column;

        }
    </style>
</head>
<body>
    <form>
<h1>Aanmelden voor borrel</h1>
<div>
<label>naam:</label>
<input type="text" name="naam"><br>
<label> email-adres:</label>
<input type="text" name="email"><br>
<div id="veg">
<label>Vegetarisch</label>
<input type="radio">Ja
<input type="radio">Nee<br>
<label>groenten:</label><br>
 boontje<input type="checkbox">
sla<input type="checkbox">
wortels<input type="checkbox">
bloemkool<input type="checkbox">

</div>


<input type="submit" value="Meld mij aam">

</div> 
    </form>
</body>
</html>