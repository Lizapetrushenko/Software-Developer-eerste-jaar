<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

   <div id="header"><h1>Artisten</h1></div> 
   <div class="knop">
    <a href="hoofd.php">home</a>
    <a href="select.php" >select</a>
    <a href="insert.php">insert artist</a>
   </div>
   <h2>Home</h2>
    <p>Site met artisten en uit welk land ze komen</p>
</body>
</html>